#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// Some sort implementation
void sort(int* array, size_t size);

#ifdef __cplusplus
}
#endif

